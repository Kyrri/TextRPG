
public interface Comparable{
	int compareTo(Object O) throws IllegalArgumentException;
	String getName();
}
